# The_Script — Linux Mint Competition Edition

This is the Linux Mint-specific build of the NOJE hardening script.

Target: Ubuntu-based Linux Mint (including Mint 21.x/22.x). The script intentionally refuses to run on Ubuntu, Debian, or LMDE so the Mint repository logic cannot be applied to the wrong distro.

## What changed for Mint

1. Repository handling now uses `/etc/apt/sources.list.d/official-package-repositories.list`, which matches the normal Mint layout, rather than treating Mint like Ubuntu and overwriting `/etc/apt/sources.list`.
2. Mint's own codename and its Ubuntu base codename are detected separately from `/etc/os-release`.
3. The script backs up the Mint repository file before changing it. It also removes only obvious duplicate Ubuntu entries from `/etc/apt/sources.list` and disables an obvious duplicate `ubuntu.sources` file, preserving backups.
4. APT periodic package-list updates and unattended upgrades are explicitly enabled in `20auto-upgrades`.
5. Competition update runs force APT phased updates to be included, preventing rollout phasing from silently leaving upgradeable packages behind.
6. The package baseline is extended from `mint-meta-core` and whichever Mint desktop meta-package (Cinnamon/MATE/Xfce) is installed, reducing false-positive package reports.
7. SSH host-key hardening now covers all private/public host-key types, including Ed25519.
8. The malware module explicitly protects `/opt/OKCUP_ScoreEngine` so it cannot mistake the competition scorer's listening process for malware.

9. The Prohibited Files action displays its complete match list and asks for individual keep/remove decisions. Keeping is the default; quitting leaves unreviewed items unchanged.
10. Unwanted Software is now a submenu with three separate workflows: (1) inventory installed APT packages outside the configured `VANILLA` core baseline and optionally review them one at a time; (2) run the existing configured unwanted-software scan using `UNWANTED_SOFTWARE`; and (3) audit installed Snap packages, flag configured exact-name matches, and review non-core Snap candidates.
11. APT removals in the non-core review are simulated first. If the transaction would remove packages beyond the single selected target, that removal is blocked rather than risking dependencies. The configured unwanted-software scan retains its existing package-by-package checks. Automatic `apt autoremove` is disabled in these workflows to avoid unreviewed removals.
12. Snap inventory marks recognized base snaps separately. Other snaps are labeled non-core/review candidates, not automatic malware detections. This cannot establish maliciousness by itself; compare names with competition requirements. Add scenario-specific prohibited Snap names to `UNWANTED_SNAPS` in `config.sh`. Keeping is the default, and quitting leaves remaining snaps unchanged.

13. User Auditing is now a submenu with (1) the existing normal user-auditing workflow and (2) a dedicated LightDM guest-session setting. The guest-session action backs up `/etc/lightdm/lightdm.conf`, ensures `allow-guest=false` in seat sections, and verifies the effective value with `lightdm --show-config` when available. It does not restart LightDM automatically, avoiding disruption to the current desktop session.

## Compatibility

Linux Mint 22.3 is the current Mint release and is offered in Cinnamon, MATE, and Xfce editions. This build detects the installed desktop meta-package instead of hardcoding one edition. Linux Mint's current repository/upgrade tooling treats Mint repositories separately from its Ubuntu base repositories.
