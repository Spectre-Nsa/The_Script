# The_Script — Linux Mint Competition Edition

This is the Linux Mint-specific build of the NOJE hardening script.

Target: Ubuntu-based Linux Mint (including Mint 21.x/22.x). The script intentionally refuses to run on Ubuntu, Debian, or LMDE so the Mint repository logic cannot be applied to the wrong distro.

## What changed for Mint

1. Repository handling now uses `/etc/apt/sources.list.d/official-package-repositories.list`, which matches the normal Mint layout, rather than treating Mint like Ubuntu and overwriting `/etc/apt/sources.list`.
2. Mint's own codename and its Ubuntu base codename are detected separately from `/etc/os-release`.
3. The script backs up the Mint repository file before changing it. It also removes only obvious duplicate Ubuntu entries from `/etc/apt/sources.list` and disables an obvious duplicate `ubuntu.sources` file, preserving backups.
4. APT periodic package-list updates and unattended upgrades are explicitly enabled in `20auto-upgrades`.
5. Competition update runs force APT phased updates to be included, preventing rollout phasing from silently leaving upgradeable packages behind.
6. The package baseline is extended from `mint-meta-core` and whichever Mint desktop meta-package (Cinnamon/MATE/Xfce) is installed, reducing false-positive package reports.
7. SSH host-key hardening now covers all private/public host-key types, including Ed25519.
8. The malware module explicitly protects `/opt/OKCUP_ScoreEngine` so it cannot mistake the competition scorer's listening process for malware.

## Compatibility

Linux Mint 22.3 is the current Mint release and is offered in Cinnamon, MATE, and Xfce editions. This build detects the installed desktop meta-package instead of hardcoding one edition. Linux Mint's current repository/upgrade tooling treats Mint repositories separately from its Ubuntu base repositories.
